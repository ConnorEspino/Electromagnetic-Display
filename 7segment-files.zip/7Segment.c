/*
 * _7Segment.c
 *
 * Created: 21.05.2015 23:40:30
 *  Author: Nicolas
 */ 


#include <avr/io.h>
#include <util/delay.h>

uint8_t charTable[10] = {0b01111110, 0b00000110, 0b01101101, 0b01001111, 0b00010111, 0b01011011, 0b01111011, 0b00001110, 0b01111111, 0b01011111};
uint8_t charDefault = 0b00001000;

void setColum(int columNr, int hiState)
{
	PORTA = (PORTA & 0b00011111) | ((columNr * 2 + hiState) << 5);
}

void setLine(int lineNr, int hiState)
{
	PORTA = (PORTA & 0b11100011) | ((lineNr * 2 + hiState) << 2);
}

void activateBlock(int blockNr)
{
	PORTA = (PORTA & 0b11111100) | (blockNr & 0x03);
}

void setBlockPwm()
{
	uint16_t i;
	
	/*activateBlock(2);
	_delay_us(60);
	activateBlock(0);
	_delay_us(15);*/
	
	for(i=0; i < 100; i++)
	{
		activateBlock(2);
		_delay_us(8);
		activateBlock(0);
		_delay_us(20);
	}
	
	for(i=0; i < 200; i++)
	{
		activateBlock(2);
		_delay_us(1);
		activateBlock(0);
		_delay_us(27);
	}
}	

void setChar(int charNr)
{
	uint8_t cchar;
	int8_t i = 0;
	int8_t j = 0;
	uint8_t l = 0;
	uint8_t c = 0;
	
	
	cchar = charTable[charNr] ^ charDefault;
	
	for (i = 6; i > -1; i--)
	{
		l = 3 - (i + 1) / 2;
		c = i / 2;
		
		if (cchar & 0x01)
		//if (charNr == i)
		{
			setLine(l, 1);
			setColum(c, 0);
			setBlockPwm();
		}
		else
		{
			setLine(l, 0);
			setColum(c, 1);
			setBlockPwm();
		}
		_delay_us(10);
		
		cchar = (cchar>>1);
	}
}

int main(void)
{
	int i = 0;
	
	DDRA = 0xFF;
	
    while(1)
    {
		i++;
		if (i > 9) i = 0;
		
		setChar(i);
		_delay_ms(1000);
    }
}